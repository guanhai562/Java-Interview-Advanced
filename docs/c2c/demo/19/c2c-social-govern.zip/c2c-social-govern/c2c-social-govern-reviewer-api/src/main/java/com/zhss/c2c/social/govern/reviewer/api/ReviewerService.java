package com.zhss.c2c.social.govern.reviewer.api;

/**
 * 评审员服务的接口
 */
public interface ReviewerService {

}
