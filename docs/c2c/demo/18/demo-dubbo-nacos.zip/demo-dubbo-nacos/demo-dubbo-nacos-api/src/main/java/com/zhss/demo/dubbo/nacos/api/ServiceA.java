package com.zhss.demo.dubbo.nacos.api;

public interface ServiceA {

    String greet(String name);

}
