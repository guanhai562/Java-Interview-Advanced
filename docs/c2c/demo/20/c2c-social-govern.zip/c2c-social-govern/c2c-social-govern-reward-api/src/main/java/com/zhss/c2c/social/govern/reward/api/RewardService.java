package com.zhss.c2c.social.govern.reward.api;

/**
 * 奖励服务的接口
 */
public interface RewardService {

}
